let pokemonList = [
    {name: "Bulbasaur", height: 7, types: ["grass","poison"]}, 
    {name: "Ivysaur", height: 1, types: ["grass","poison"]}, 
    {name: "Venusaur", height: 2, types: ["grass","poison"]}
]; 

for (let i=0; i < pokemonList.length; document.write(pokemonList[i].name + height));